/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.part1;

    import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public final class Message {
    private final String messageID;
    private final int messageNumber;
    private final String messageHash;
    private final String recipient;
    private final String message;

    private static int totalMessagesSent = 0;
    private static String lastMessage = "";

    public Message(int messageNumber, String recipient, String message) {
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.message = (message == null) ? "" : message;
        this.messageID = generateMessageID();
        this.messageHash = createMessageHash();
    }

    public final String generateMessageID() {
        Random random = new Random();
        StringBuilder id = new StringBuilder();

        for (int i = 0; i < 10; i++) {
            id.append(random.nextInt(10));
        }

        return id.toString();
    }

    public boolean checkMessageID() {
        return messageID.length() == 10;
    }

    public String checkRecipientCell() {
        if (isRecipientValid()) {
            return "Cellphone number is successfully captured.";
        } else {
            return "Cellphone number is incorrectly formatted or does not contain an international code, please correct the number and try again.";
        }
    }

    public boolean isRecipientValid() {
        return recipient != null && recipient.matches("^\\+\\d{1,3}\\d{7,10}$");
    }

    public String checkMessageLength() {
        if (message.length() <= 250) {
            return "Message ready to send.";
        } else {
            int extraCharacters = message.length() - 250;
            return "Message exceeds 250 characters by " + extraCharacters
                    + ", please reduce size.";
        }
    }

    public boolean isMessageValid() {
        return message.length() <= 250;
    }

    public String createMessageHash() {
        if (message.trim().isEmpty()) {
            return (messageID.substring(0, 2) + ":" + messageNumber).toUpperCase();
        }

        String[] words = message.trim().split("\\s+");

        String firstWord = words[0].replaceAll("[^a-zA-Z0-9]", "");
        String lastWord = words[words.length - 1].replaceAll("[^a-zA-Z0-9]", "");

        String hash = messageID.substring(0, 2) + ":" +
                messageNumber + ":" +
                firstWord + lastWord;

        return hash.toUpperCase();
    }

    public String sendMessage(int option) {
        switch (option) {
            case 1 -> {
                totalMessagesSent++;
                lastMessage = printMessageDetails();
                return "Message successfully sent.";
            }
            case 0 -> {
                return "Press 0 to delete message.";
            }
            case 2 -> {
                return storeMessage();
            }
            default -> {
                return "Invalid option.";
            }
        }
    }

    public String printMessage() {
        if (message.isEmpty()) {
            return "No messages sent.";
        } else {
            return printMessageDetails();
        }
    }

    public int returnTotalMessages() {
        return totalMessagesSent;
    }

    public static String getLastMessage() {
        return lastMessage;
    }

    public String printMessageDetails() {
        return "Message ID: " + messageID +
                System.lineSeparator() +
                "Message Hash: " + messageHash +
                System.lineSeparator() +
                "Recipient: " + recipient +
                System.lineSeparator() +
                "Message: " + message;
    }

    public String storeMessage() {
        try (FileWriter writer = new FileWriter("messages.txt", true)) {
            writer.write(printMessageDetails());
            writer.write(System.lineSeparator() + System.lineSeparator());
            return "Message successfully stored.";
        } catch (IOException e) {
            return "Failed to store message: " + e.getMessage();
        }
    }
}