/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.part1;

/**
 *
 *  @author Student
 */
public class Login {

    private String username;
    private String password;
    private String cellPhoneNumber;
    private String firstName;
    private String lastName;

    public void setUserNames(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public boolean checkUserName(String username) {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity(String password) {
        String pattern = "^(?=.*[A-Z])(?=.*[0-9])(?=.*[^a-zA-Z0-9]).{8,}$";
        return password != null && password.matches(pattern);
    }

    public boolean checkCellPhoneNumber(String number) {
        String pattern = "^\\+27\\d{9}$";
        return number != null && number.matches(pattern);
    }

    public String registerUser(String username, String password, String cellPhoneNumber) {
        boolean validUsername = checkUserName(username);
        boolean validPassword = checkPasswordComplexity(password);
        boolean validPhone = checkCellPhoneNumber(cellPhoneNumber);

        StringBuilder response = new StringBuilder();

        if (!validUsername) {
            response.append("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.")
                    .append(System.lineSeparator());
        }

        if (!validPassword) {
            response.append("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.")
                    .append(System.lineSeparator());
        }

        if (!validPhone) {
            response.append("Cell phone number incorrectly formatted or does not contain international code.")
                    .append(System.lineSeparator());
        }

        if (validUsername && validPassword && validPhone) {
            this.username = username;
            this.password = password;
            this.cellPhoneNumber = cellPhoneNumber;
            return "User successfully registered.";
        }

        return response.toString();
    }

    public boolean loginUser(String username, String password) {
        return this.username != null && this.password != null
                && this.username.equals(username)
                && this.password.equals(password);
    }

    public String returnLoginStatus(boolean loginStatus) {
        if (loginStatus) {
            return "Welcome " + this.firstName + ", " + this.lastName
                    + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}