/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.part1;

import java.util.Scanner;

/**
 *
 * @ @author Student
 */
import java.util.Scanner;
public class Part1 {

    public static void main(String[] args) {
       
        // This will help with user input 
          Scanner sc = new Scanner(System.in);
        Login login = new Login();

        // This will help with user input
        System.out.println("********** Registration **************");
        System.out.print("Enter your first name: ");
        String firstName = sc.nextLine();

        System.out.print("Enter your last name: ");
        String lastName = sc.nextLine();

        login.setUserNames(firstName, lastName);

        // Checks if the username is valid
        boolean usernameValid = false;
        String username = " ";
        while (!usernameValid) {
            System.out.print("Enter username (must include '_' and be <= 5 characters): ");
            username = sc.nextLine();
          usernameValid = login.checkUserName(username);
            if (usernameValid) {
                System.out.println("Username successfully captured");
            } else {
                System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length");
          }
        }

        // Chceks if the Password is valid
        boolean passwordValid = false;
        String password = " ";
        while (!passwordValid) {
            System.out.print("Enter password (at least 8 characters, a capital letter, number, special character): ");
            password = sc.nextLine();
            passwordValid = login.checkPasswordComplexity(password);
            if (passwordValid) {
                System.out.println("Password successfully captured");
            } else {
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character");
            }
        }

        // Checks if the Cell Phone is valid
        boolean phoneValid = false;
        String phone = " ";
        while (!phoneValid) {
            System.out.print("Enter SA cellphone number (e.g., +2783***4567): ");
            phone = sc.nextLine();
            phoneValid = login.checkCellPhoneNumber(phone);
            if (phoneValid) {
                System.out.println("Cell phone number successfully added.");
            } else {
                System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
            }
        }

        System.out.println("\nRegistration complete ");

        // LOGIN
        System.out.println("\n=== Login ===");

        System.out.print("Enter your username: ");
        String loginUsername = sc.nextLine();

        System.out.print("Enter your password: ");
        String loginPassword = sc.nextLine();

        boolean loggedIn = login.loginUser(loginUsername, loginPassword);
        System.out.println(login.returnLoginStatus(loggedIn));
    

    }
}